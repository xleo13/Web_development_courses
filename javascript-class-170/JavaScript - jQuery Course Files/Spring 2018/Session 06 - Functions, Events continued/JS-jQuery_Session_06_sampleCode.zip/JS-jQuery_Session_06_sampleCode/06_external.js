'use strict';

x = 3; // This will cause an error because x is not defined as a variable
alert(x);