   // Define a function
   function sayHello() {
       alert("Hello");
   }
